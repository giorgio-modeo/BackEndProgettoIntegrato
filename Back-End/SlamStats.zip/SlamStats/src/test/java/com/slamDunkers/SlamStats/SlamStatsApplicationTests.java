package com.slamDunkers.SlamStats;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlamStatsApplicationTests {

	@Test
	void contextLoads() {
	}

}
