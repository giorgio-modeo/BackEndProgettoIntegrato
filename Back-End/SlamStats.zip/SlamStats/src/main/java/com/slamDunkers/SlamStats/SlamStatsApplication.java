package com.slamDunkers.SlamStats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlamStatsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SlamStatsApplication.class, args);
	}

}
